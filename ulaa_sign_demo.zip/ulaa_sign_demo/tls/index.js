// index.js
module.exports = {
    rootCertificates: undefined
};
